import './index.css'
import Header from './components/Header'
import Sidebar from './components/Sidebar'

function App() {

  return (
    <>
      <div className="bg-red-500 text-white p-4">Tailwind Test</div>
      <Header />
      <Sidebar />
    </>
  )
}

export default App
